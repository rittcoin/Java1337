/**
 * @(#)HelloRitterWorld.java
 *
 *
 * @author Ryan Ritter
 * @version 1.00 2019/9/5
 */


public class HelloRitterWorld {

    public static void main(String[] args) {

    	// TODO, add your application code
    	System.out.println("Hello World!");
    }
}